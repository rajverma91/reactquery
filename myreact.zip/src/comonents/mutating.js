import React from 'react'

const Mutating = () => {
  return (
    <div>
      <>Mutating</>
    </div>
  )
}

export default Mutating
