import React from 'react'

const NoPage = () => {
  return (
    <div>
      <h1>NoPage</h1>
    </div>
  )
}

export default NoPage
